package com.example.CampusLink.controller.Geral;

import com.example.CampusLink.dao.alunoDAO;
import com.example.CampusLink.dao.professorDAO;
import com.example.CampusLink.dao.turmaDAO;
import com.example.CampusLink.dto.TurmaDTO;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import com.example.CampusLink.dto.ConteudoDTO;
import com.example.CampusLink.service.ConteudoService;
import org.springframework.web.multipart.MultipartFile;
import com.example.CampusLink.service.ArquivoService;
import java.sql.SQLException;
import java.util.List;
import com.example.CampusLink.dto.ArquivoDTO;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.Map;

@Controller
public class turmasController {

    private static final Logger logger = LoggerFactory.getLogger(turmasController.class);

    @Autowired
    private professorDAO professorDAO;

    @Autowired
    private alunoDAO alunoDAO;

    @Autowired
    private turmaDAO turmaDAO;

    @Autowired
    private ConteudoService conteudoService;

    @Autowired
    private ArquivoService arquivoService;

    @GetMapping("/turmas")
    public String Turmas(Model model, HttpSession session) throws SQLException {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        model.addAttribute("turma", new TurmaDTO());
        List<TurmaDTO> turmas = List.of();

        //recuperar turmas que o usuario esta
        String tipoUsuario = session.getAttribute("tipoUsuario").toString();
        if ("aluno".equalsIgnoreCase(tipoUsuario)) {
            turmas = turmaDAO.buscarTurmasDoUsuario("aluno", alunoDAO.buscarPorIDAluno(session.getAttribute("email2FA").toString()));
        } else if ("professor".equalsIgnoreCase(tipoUsuario)) {
            turmas = turmaDAO.buscarTurmasDoUsuario("professor", professorDAO.buscarPorIDProfessor(session.getAttribute("email2FA").toString()));
        }

        model.addAttribute("turmas", turmas);

        return "Geral/turmas";
    }

    @GetMapping("/turmas/{id}")
    public String ambienteTurma(@PathVariable String id, Model model, HttpSession session) throws SQLException {
        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        model.addAttribute("idTurma", id);
        TurmaDTO turma = turmaDAO.buscarTurmaPorId(id);
        if (turma == null) {
            return "redirect:/turmas";
        }

        boolean isTurmaAdmin = false;
        if (session.getAttribute("tipoUsuario") != null && "professor".equalsIgnoreCase(session.getAttribute("tipoUsuario").toString())) {
            String idProfessor = professorDAO.buscarPorIDProfessor(session.getAttribute("email2FA").toString());
            isTurmaAdmin = turma.getIdProprietario() != null && turma.getIdProprietario().toString().equals(idProfessor);
        }

        List<TurmaDTO> participantesTurma = turmaDAO.buscarParticipantesDaTurma(id);

        model.addAttribute("turma", turma);
        model.addAttribute("participantesTurma", participantesTurma);
        model.addAttribute("isTurmaAdmin", isTurmaAdmin);
        model.addAttribute("conteudo", new ConteudoDTO());
        List<ConteudoDTO> conteudos = conteudoService.listarPorTurma(Long.parseLong(id));
        model.addAttribute("conteudos", conteudos);

        Map<Long, ArquivoDTO> arquivosPorConteudo = new HashMap<>();
        for (ConteudoDTO conteudo : conteudos) {
            ArquivoDTO arquivo = arquivoService.buscarMaisRecentePorConteudo(conteudo.getId());
            if (arquivo != null) {
                arquivosPorConteudo.put(conteudo.getId(), arquivo);
            }
        }
        model.addAttribute("arquivosPorConteudo", arquivosPorConteudo);
        return "Geral/ambienteTurma";
    }
    @PostMapping("/turmas/{id}/conteudos")
    public String criarConteudo(@PathVariable Long id,
                                @Valid @ModelAttribute("conteudo") ConteudoDTO conteudoDTO,
                                BindingResult result,
                                @RequestParam(value = "arquivo", required = false) MultipartFile arquivo,
                                HttpSession session,
                                Model model) throws SQLException {

        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }
        if (!"professor".equals(session.getAttribute("tipoUsuario"))) {
            logger.warn("[criarConteudo] aluno tentou cadastrar conteúdo na turma {}.", id);
            return "redirect:/turmas/" + id;
        }
        if (result.hasErrors()) {
            model.addAttribute("abrirModalAdicionarConteudo", true);
            model.addAttribute("idTurma", String.valueOf(id));
            model.addAttribute("turma", turmaDAO.buscarTurmaPorId(String.valueOf(id)));

            List<ConteudoDTO> conteudos = conteudoService.listarPorTurma(id);
            model.addAttribute("conteudos", conteudos);

            Map<Long, ArquivoDTO> arquivosPorConteudo = new HashMap<>();
            for (ConteudoDTO conteudo : conteudos) {
                ArquivoDTO arquivoExistente = arquivoService.buscarMaisRecentePorConteudo(conteudo.getId());
                if (arquivoExistente != null) {
                    arquivosPorConteudo.put(conteudo.getId(), arquivoExistente);
                }
            }
            model.addAttribute("arquivosPorConteudo", arquivosPorConteudo);

            return "Geral/ambienteTurma";
        }
        String idProfessor = professorDAO.buscarPorIDProfessor(session.getAttribute("email2FA").toString());

        conteudoDTO.setIdTurma(id);
        conteudoDTO.setIdProfessor(Long.parseLong(idProfessor));

        try {
            conteudoService.criar(conteudoDTO, arquivo);
        } catch (IllegalArgumentException e) {
            model.addAttribute("mensagemErro", e.getMessage());
            model.addAttribute("abrirModalAdicionarConteudo", true);
            model.addAttribute("idTurma", String.valueOf(id));
            model.addAttribute("turma", turmaDAO.buscarTurmaPorId(String.valueOf(id)));

            List<ConteudoDTO> conteudos = conteudoService.listarPorTurma(id);
            model.addAttribute("conteudos", conteudos);

            Map<Long, ArquivoDTO> arquivosPorConteudo = new HashMap<>();
            for (ConteudoDTO conteudo : conteudos) {
                ArquivoDTO arquivoExistente = arquivoService.buscarMaisRecentePorConteudo(conteudo.getId());
                if (arquivoExistente != null) {
                    arquivosPorConteudo.put(conteudo.getId(), arquivoExistente);
                }
            }
            model.addAttribute("arquivosPorConteudo", arquivosPorConteudo);

            return "Geral/ambienteTurma";
        }

        return "redirect:/turmas/" + id;
    }

    @PostMapping("/criarTurma")
    public String criarTurma(@Valid @ModelAttribute("turma") TurmaDTO turmaDTO, BindingResult result, HttpSession session, Model model, RedirectAttributes redirectAttributes) throws SQLException {

        if (result.hasErrors()) {
            model.addAttribute("abrirModalCriarTurma", true);
            return "Geral/turmas";
        }

        if (session.getAttribute("tipoUsuario").equals("aluno")) {
            return "Geral/home";
        }

        String idProfessor = professorDAO.buscarPorIDProfessor(session.getAttribute("email2FA").toString());

        //Insere turma no banco de dados
        professorDAO.InsertTurmasIntoBD(turmaDTO.getNomeTurma(), turmaDTO.getDescricao(), idProfessor);

        //Insere x_turma no banco de dados
        professorDAO.InsertProfessor_TurmaIntoBD(idProfessor, turmaDAO.buscarUltimaTurmaPorProfessor(idProfessor));

        redirectAttributes.addFlashAttribute("mensagemSucesso", "Turma cadastrada com sucesso.");
        return "redirect:/turmas";
    }

    @PostMapping("/turmas/{id}/conteudos/{idConteudo}/excluir")
    public String excluirConteudo(@PathVariable Long id,
                                  @PathVariable Long idConteudo,
                                  HttpSession session) {

        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"professor".equals(session.getAttribute("tipoUsuario"))) {
            logger.warn("[excluirConteudo] aluno tentou excluir conteúdo {} da turma {}.", idConteudo, id);
            return "redirect:/turmas/" + id;
        }

        conteudoService.excluir(idConteudo);

        return "redirect:/turmas/" + id;
    }
    @PostMapping("/turmas/{id}/conteudos/{idConteudo}/editar")
    public String editarConteudo(@PathVariable Long id,
                                 @PathVariable Long idConteudo,
                                 @Valid @ModelAttribute("conteudo") ConteudoDTO conteudoDTO,
                                 BindingResult result,
                                 @RequestParam(value = "arquivo", required = false) MultipartFile arquivo,
                                 HttpSession session,
                                 Model model) throws SQLException {

        if (session.getAttribute("usuarioLogado") == null) {
            return "redirect:/login";
        }

        if (!"professor".equals(session.getAttribute("tipoUsuario"))) {
            logger.warn("[editarConteudo] aluno tentou editar conteúdo {} da turma {}.", idConteudo, id);
            return "redirect:/turmas/" + id;
        }

        if (result.hasErrors()) {
            model.addAttribute("abrirModalAdicionarConteudo", true);
            model.addAttribute("idTurma", String.valueOf(id));
            model.addAttribute("turma", turmaDAO.buscarTurmaPorId(String.valueOf(id)));

            List<ConteudoDTO> conteudos = conteudoService.listarPorTurma(id);
            model.addAttribute("conteudos", conteudos);

            Map<Long, ArquivoDTO> arquivosPorConteudo = new HashMap<>();
            for (ConteudoDTO conteudo : conteudos) {
                ArquivoDTO arquivoExistente = arquivoService.buscarMaisRecentePorConteudo(conteudo.getId());
                if (arquivoExistente != null) {
                    arquivosPorConteudo.put(conteudo.getId(), arquivoExistente);
                }
            }
            model.addAttribute("arquivosPorConteudo", arquivosPorConteudo);

            return "Geral/ambienteTurma";
        }

        conteudoDTO.setId(idConteudo);

        try {
            conteudoService.atualizar(conteudoDTO);

            if (arquivo != null && !arquivo.isEmpty()) {
                arquivoService.salvar(arquivo, idConteudo);
            }
        } catch (IllegalArgumentException e) {
            model.addAttribute("mensagemErro", e.getMessage());
            model.addAttribute("abrirModalAdicionarConteudo", true);
            model.addAttribute("idTurma", String.valueOf(id));
            model.addAttribute("turma", turmaDAO.buscarTurmaPorId(String.valueOf(id)));

            List<ConteudoDTO> conteudos = conteudoService.listarPorTurma(id);
            model.addAttribute("conteudos", conteudos);

            Map<Long, ArquivoDTO> arquivosPorConteudo = new HashMap<>();
            for (ConteudoDTO conteudo : conteudos) {
                ArquivoDTO arquivoExistente = arquivoService.buscarMaisRecentePorConteudo(conteudo.getId());
                if (arquivoExistente != null) {
                    arquivosPorConteudo.put(conteudo.getId(), arquivoExistente);
                }
            }
            model.addAttribute("arquivosPorConteudo", arquivosPorConteudo);

            return "Geral/ambienteTurma";
        }

        return "redirect:/turmas/" + id;
    }

    @PostMapping("/adicionarPessoas")
    public String adicionarPessoas(@ModelAttribute("turma") TurmaDTO turmaDTO, HttpSession session, Model model) throws SQLException {

        if (session.getAttribute("usuarioLogado") == null) {
            logger.warn("[adicionarPessoas] usuário não autenticado; redirecionando para login.");
            return "redirect:/login";
        }

        if (session.getAttribute("tipoUsuario") != null && session.getAttribute("tipoUsuario").equals("aluno")) {
            logger.warn("[adicionarPessoas] aluno tentou adicionar pessoa à turma.");
            return "Geral/home";
        }

        if (turmaDTO.getEmailPessoa() == null || turmaDTO.getEmailPessoa().isBlank()) {
            logger.warn("[adicionarPessoas] e-mail vazio para turma {}.", turmaDTO.getId());
            model.addAttribute("idTurma", turmaDTO.getId());
            model.addAttribute("turma", turmaDAO.buscarTurmaPorId(String.valueOf(turmaDTO.getId())));
            model.addAttribute("conteudo", new ConteudoDTO());
            model.addAttribute("conteudos", conteudoService.listarPorTurma(turmaDTO.getId()));
            return "Geral/ambienteTurma";
        }

        boolean pessoaAdicionada = turmaDAO.inserirPessoaTurma(turmaDTO.getEmailPessoa().trim(), String.valueOf(turmaDTO.getId()));

        if (pessoaAdicionada) {
            model.addAttribute("mensagemSucesso", "Pessoa adicionada com sucesso.");
        } else {
            model.addAttribute("mensagemErro", "Não foi possível adicionar a pessoa informada.");
        }

        TurmaDTO turmaAtual = turmaDAO.buscarTurmaPorId(String.valueOf(turmaDTO.getId()));
        model.addAttribute("turma", turmaAtual);
        model.addAttribute("participantesTurma", turmaDAO.buscarParticipantesDaTurma(String.valueOf(turmaDTO.getId())));
        model.addAttribute("abrirModalParticipantes", true);
        return "Geral/ambienteTurma";
    }

    @PostMapping("/excluirTurma")
    public String excluirTurma(@ModelAttribute("turma") TurmaDTO turmaDTO, HttpSession session, Model model, RedirectAttributes redirectAttributes) throws SQLException {

        if (session.getAttribute("usuarioLogado") == null) {
            logger.warn("[excluirTurma] usuário não autenticado; redirecionando para login.");
            return "redirect:/login";
        }

        if (session.getAttribute("tipoUsuario") == null || !"professor".equalsIgnoreCase(session.getAttribute("tipoUsuario").toString())) {
            logger.warn("[excluirTurma] usuário tentou excluir turma sem permissão.");
            return "Geral/home";
        }

        String idProfessor = professorDAO.buscarPorIDProfessor(session.getAttribute("email2FA").toString());
        turmaDAO.excluirTurma(String.valueOf(turmaDTO.getId()), idProfessor);

        redirectAttributes.addFlashAttribute("mensagemSucesso", "Turma excluída com sucesso.");
        return "redirect:/turmas";
    }

    @PostMapping("/removerPessoas")
    public String removerPessoas(@ModelAttribute("turma") TurmaDTO turmaDTO, HttpSession session, Model model) throws SQLException {

        if (session.getAttribute("usuarioLogado") == null) {
            logger.warn("[removerPessoas] usuário não autenticado; redirecionando para login.");
            return "redirect:/login";
        }

        if (session.getAttribute("tipoUsuario") != null && session.getAttribute("tipoUsuario").equals("aluno")) {
            logger.warn("[removerPessoas] aluno tentou remover pessoas da turma.");
            return "Geral/home";
        }

        if (turmaDTO.getEmailPessoa() == null || turmaDTO.getEmailPessoa().isBlank()) {
            logger.warn("[removerPessoas] e-mail vazio para turma {}.", turmaDTO.getId());
            model.addAttribute("idTurma", turmaDTO.getId());
            model.addAttribute("turma", turmaDAO.buscarTurmaPorId(String.valueOf(turmaDTO.getId())));
            return "Geral/ambienteTurma";
        }

        boolean removido = turmaDAO.revomerPessoaTurma(turmaDTO.getEmailPessoa().trim(), String.valueOf(turmaDTO.getId()));

        if (!removido) {
            model.addAttribute("mensagemErro", "Não foi possível remover a pessoa informada. Verifique se ela está cadastrada na turma ou se é o professor administrador.");
        } else {
            model.addAttribute("mensagemSucesso", "Pessoa removida com sucesso.");
        }

        TurmaDTO turmaAtual = turmaDAO.buscarTurmaPorId(String.valueOf(turmaDTO.getId()));
        model.addAttribute("turma", turmaAtual);
        model.addAttribute("participantesTurma", turmaDAO.buscarParticipantesDaTurma(String.valueOf(turmaDTO.getId())));
        model.addAttribute("abrirModalParticipantes", true);
        return "Geral/ambienteTurma";
    }
    @ExceptionHandler(org.springframework.web.multipart.MaxUploadSizeExceededException.class)
    public String tratarArquivoMuitoGrande(
            jakarta.servlet.http.HttpServletRequest request,
            RedirectAttributes redirectAttributes) {

        String uri = request.getRequestURI();
        String id = uri.replaceAll(".*?/turmas/(\\d+).*", "$1");

        redirectAttributes.addFlashAttribute(
                "mensagemErro",
                "O arquivo enviado é muito grande. O limite é de 50 MB."
        );

        return "redirect:/turmas/" + id;
    }


}
